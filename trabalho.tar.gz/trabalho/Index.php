<?php
$servername = "localhost";
$username = "seu_usuario";
$password = "sua_senha";
$dbname = "Banco.sql";

// Criar a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
  die("Falha na conexão: " . $conn->connect_error);
}
?>


<?php
// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Verificar se os campos foram preenchidos
  if (!empty($_POST["produto"]) && !empty($_POST["quantidade"]) && !empty($_POST["preco"])) {
    // Preparar a instrução SQL
    $sql = "INSERT INTO carrinho (produto, quantidade, preco) VALUES (?, ?, ?)";

    // Preparar a declaração
    $stmt = $conn->prepare($sql);

    // Vincular os parâmetros
    $stmt->bind_param("sii", $_POST["produto"], $_POST["quantidade"], $_POST["preco"]);

    // Executar a declaração
    if ($stmt->execute()) {
      echo "Produto adicionado ao carrinho com sucesso!";
    } else {
      echo "Ocorreu um erro ao adicionar o produto ao carrinho: " . $stmt->error;
    }

    // Fechar a declaração
    $stmt->close();
  } else {
    echo "Por favor, preencha todos os campos.";
  }
}
?>
